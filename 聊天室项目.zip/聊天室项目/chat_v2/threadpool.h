#ifndef THREADPOOL_H
#define THREADPOOL_H

#include "array_queue.h"
typedef struct ThreadPool
{
	pthread_t* tid;		//线程的id数组
	size_t thread_cnt;		//线程数量
	void (*task)(void*);		//线程运行函数
	ArrayQueue* queue;	//队列
	pthread_mutex_t mutex;	//互斥量
	pthread_cond_t full;		//队列满的时候的睡眠条件
	pthread_cond_t null;	//队列空的时候的睡眠条件
}ThreadPool;

// 创建线程池，参数：线程的数量，队列的容量，运行函数
ThreadPool* tp_create(size_t cnt,size_t cal,void (*task)(void*));

// 销毁线程池
void tp_destory(ThreadPool* tp);

// 启动
void start(ThreadPool* tp);

// 生产
void tp_push(ThreadPool* tp,void* ptr);

// 消费
void* tp_pop(ThreadPool* tp);

#endif//THREADPOOL_H
